####Adivinhe o numero!!!
#Made by Gustavo Machado

import random

def derrota(tentativa):
  if tentativa == 0:
    return True

def gera_num():
  num = random.randint(1, 100)
  return num

def dificuldade():
  diff = input("Qual dificuldade voce quer? 'f' para facil ou 'd' para dificil: ").lower()
  if diff == "f":
    print("voce tem 10 tentativas")
    return 10
  elif diff == "d":
    print("voce tem 5 tentativas")
    return 5
  else:
    return 10

def chute(num, tentativa, vidas):
  if num > tentativa:
    print(f"O numero é maior que o seu chute, voce tem {vidas - 1} restantes\n")
    return vidas - 1
  elif num < tentativa:
    print(f"O numero é menor que o seu chute, voce tem {vidas - 1} restantes\n")
    return vidas - 1
  else:
    print(f"Parabens voce acertou o numero com {vidas-1} tentativas restantes")
    return 1000

dif = dificuldade()
num = gera_num()
vidas = dif


for i in range(dif):
  tentativa = input("Quando numero voce acha que eh? ")
  tentativa = int(tentativa)
  vidas = chute(num, tentativa, vidas)
  if vidas == 1000:
    break
  if derrota(vidas):
    print(f"Voce perdeu, o numero era: {num}")
    
  